<div class="container mt-5">
    <div class="row mt-5">
        <div class="col-lg-11 mx-auto">
            <h1 class="text-center"><?= $article[0]->title?></h1><br>
            <h6 class="text-center">By: <?= $article[0]->NAME?></h6> <br> <br> <br>
            <div>
                <?= $article[0]->article?>
            </div>
        </div>
    </div>  
</div>